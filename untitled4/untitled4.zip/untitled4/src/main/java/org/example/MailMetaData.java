package org.example;

public class MailMetaData {
    public static final String HostServer ="smtp.gmail.com";
    public static final String port="465";

    public static final String sslProperty="mail.smtp.ssl.enable";
    public static final String authPerm="mail.smtp.auth";

    public static final String myUserMail="gpkp1522256@gmail.com";

    public static final String myPass="jdzffqxeioufdlhl";
    public static final String receiverMail="omkarkore1431@gmail.com";

}
